insert into room (rid,hid,rsize,rprice,rimage) values (100, 100,'2bhk','1000', '/assets/r1.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (101, 100,'2bhk','2000', '/assets/r2.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (102, 100,'3bhk','4000', '/assets/r3.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (103, 100,'2bhk','1000', '/assets/r4.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (104, 101,'2bhk','2000', '/assets/r7.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (105, 101,'3bhk','4000', '/assets/r8.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (106, 101,'2bhk','1000', '/assets/r9.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (107, 101,'2bhk','2000', '/assets/r10.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (108, 102,'3bhk','4000', '/assets/r11.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (109, 102,'2bhk','1000', '/assets/r12.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (110, 102,'2bhk','2000', '/assets/r13.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (111, 102,'3bhk','4000', '/assets/r14.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (112, 103,'2bhk','1000', '/assets/r15.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (113, 103,'2bhk','2000', '/assets/r16.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (114, 103,'3bhk','4000', '/assets/r17.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (115, 103,'2bhk','1000', '/assets/r18.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (116, 104,'2bhk','2000', '/assets/r19.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (117, 104,'3bhk','4000', '/assets/r20.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (118, 104,'2bhk','1000', '/assets/r21.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (119, 104,'2bhk','2000', '/assets/r22.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (120, 105,'3bhk','4000', '/assets/r23.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (121, 105,'2bhk','1000', '/assets/r24.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (122, 105,'2bhk','2000', '/assets/r25.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (123, 105,'3bhk','4000', '/assets/r26.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (124, 106,'2bhk','1000', '/assets/r27.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (125, 106,'2bhk','2000', '/assets/r28.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (126, 106,'3bhk','4000', '/assets/r29.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (127, 106,'2bhk','1000', '/assets/r30.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (128, 107,'2bhk','2000', '/assets/r31.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (129, 107,'3bhk','4000', '/assets/r32.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (130, 107,'2bhk','1000', '/assets/r33.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (131, 107,'2bhk','2000', '/assets/r34.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (132, 108,'3bhk','4000', '/assets/r35.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (133, 108,'2bhk','1000', '/assets/r36.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (134, 108,'2bhk','2000', '/assets/r37.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (135, 108,'3bhk','4000', '/assets/r38.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (136, 109,'2bhk','1000', '/assets/r39.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (137, 109,'2bhk','2000', '/assets/r40.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (138, 109,'3bhk','4000', '/assets/r27.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (139, 109,'2bhk','1000', '/assets/r28.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (140, 100,'2bhk','2000', '/assets/r15.jpg');
insert into room (rid,hid,rsize,rprice,rimage) values (141, 100,'3bhk','4000', '/assets/r16.jpg');


 

 

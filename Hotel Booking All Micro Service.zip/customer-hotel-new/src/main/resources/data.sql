insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (101, 'John Smith', 'john_smith@gmail.com', '555-555-0101', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (102, 'Rafael Escosio Fernandez', 'rafaele@gmail.com', '2215102613', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (103, 'David E. Dupree', 'davide@gmail.com', '2205216695', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (104, 'Fatima Mohamed', 'fatima@gmail.com', '9645812222', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (105, 'Bahja Aldogan Bayrot', 'bahjabayrot@gmail.com', '9632145783', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (106, 'Leanne Graham', 'leanne@gmail.com', '9623786912', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (107, 'Ervin Howell', 'ervinhowell@gmail.com', '9875621332', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (108, 'Clementine Bauch', 'clemenbauch@gmail.com', '2298756314', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (109, 'Patricia Lebsack', 'patricia@gmail.com', '2265329842', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (110, 'Chelsey Dietrich', 'chelseyd@gmail.com', '2232956798', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (111, 'Kurtis Weissnat', 'kurtisWei@gmail.com', '7596214563', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (112, 'Nicholas Runolfsdottir', 'nicholas@gmail.com', '7975621489', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (113, 'Glenna Reichert', 'glennareich@gmail.com', '9036789523', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (114, 'Mukesh Sharma', 'mukesh@gmail.com', '9212327628', '12345', '/assets/img.img');
insert into customer (cid, cname, cemail, cphoneno, cpassword, cimage) values (115, 'R.K. Gupta', 'rkgupta@gmail.com', '9810015824', '12345', '/assets/img.img');









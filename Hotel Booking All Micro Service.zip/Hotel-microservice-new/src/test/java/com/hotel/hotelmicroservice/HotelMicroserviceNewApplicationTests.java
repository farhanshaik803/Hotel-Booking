package com.hotel.hotelmicroservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelMicroserviceNewApplicationTests {

	@Test
	void contextLoads() {
	}

}

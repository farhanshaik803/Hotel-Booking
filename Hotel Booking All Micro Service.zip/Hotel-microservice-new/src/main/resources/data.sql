insert into hotel (hid,hname,hlocation,himage,hrating) values (100, 'Taj Palace', 'Chanakyapuri, New Delhi', 'assets/h1.jpg', 5);
insert into hotel (hid,hname,hlocation,himage,hrating) values (101, 'The Leela Palace', 'Old Airport Road, Bangalore', 'assets/h2.jpg', 5);
insert into hotel (hid,hname,hlocation,himage,hrating) values (102, 'The Oberoi', 'Nariman Point, Mumbai', 'assets/h3.jpg', 4);
insert into hotel (hid,hname,hlocation,himage,hrating) values (103, 'Kochi Marriott Hotel', 'Cochin, Kerala', 'assets/h4.jpg', 4);
insert into hotel (hid,hname,hlocation,himage,hrating) values (104, 'Trident Chennai', 'South Chennai, Chennai', 'assets/h5.jpg', 4);
insert into hotel (hid,hname,hlocation,himage,hrating) values (105, 'Vivanta Goa', 'Panaji, Goa', 'assets/h6.jpg', 4);
insert into hotel (hid,hname,hlocation,himage,hrating) values (106, ' The Residency Towers ', 'Puducherry, Tamil Nadu', 'assets/h7.jpg', 4);
insert into hotel (hid,hname,hlocation,himage,hrating) values (107, ' The Lalit Laxmi Vilas Palace', 'Udaipur, Rajasthan', 'assets/h8.jpg', 4);
insert into hotel (hid,hname,hlocation,himage,hrating) values (108, ' Radisson Blu Plaza Hotel ', '1 MG Road, Mysore', 'assets/h9.jpg', 4);
insert into hotel (hid,hname,hlocation,himage,hrating) values (109, 'Pahalgam Hotel', 'Pahalgam, Jammu and Kashmir', 'assets/h10.jpg', 5);

 
